
from src.simulation import run_simulation

if __name__ == "__main__":
    run_simulation()
