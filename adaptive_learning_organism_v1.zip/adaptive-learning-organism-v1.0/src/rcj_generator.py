
def generate_rcj(tag):
    return {
        "reflection": f"What did you learn from {tag}?",
        "challenge": f"Can you improve on {tag}?",
        "justification": f"Why is {tag} important?"
    }
