
def tag_content(content):
    return {"tags": ["reflection", "challenge", "justification"]}
