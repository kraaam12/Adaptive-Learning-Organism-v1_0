
from src.simulation import run_simulation

def test_run_simulation():
    run_simulation()
